import connexion
import six

from swagger_server import util


def get_copy_path(copy=None):  # noqa: E501
    """path

     # noqa: E501

    :param copy: 
    :type copy: str

    :rtype: None
    """
    return 'do some magic!'


def get_list_path(query=None):  # noqa: E501
    """list

     # noqa: E501

    :param query: 
    :type query: str

    :rtype: None
    """
    return 'do some magic!'
