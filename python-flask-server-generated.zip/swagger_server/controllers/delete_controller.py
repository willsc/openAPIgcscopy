import connexion
import six

from swagger_server import util


def get_delete_path(query=None):  # noqa: E501
    """Delete

     # noqa: E501

    :param query: 
    :type query: str

    :rtype: None
    """
    return 'do some magic!'
